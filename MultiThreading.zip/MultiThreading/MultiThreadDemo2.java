package MultiThreading;

class MultiThread2 implements Runnable
{
	public void fun1()
	{
		System.out.println("this is fun1");
	}
	public void fun2()
	{
		System.out.println("this is fun2");
	}
	public void run()
	{
		fun1();
		fun2();
		System.out.println("id is:"+Thread.currentThread().getId());
		System.out.println("name is:"+Thread.currentThread().getName());
		
	}
}

public class MultiThreadDemo2 {

	public static void main(String[] args)
	{
		MultiThread2 obj1= new MultiThread2();
		Thread th1=new Thread(obj1);
		th1.start();// will execute run()
		
		System.out.println("+++++++++++++++++++++++++++++++");
		
		MultiThread2 obj2= new MultiThread2();
		Thread th2=new Thread(obj2);
		th2.start();
		
	
	}

}
