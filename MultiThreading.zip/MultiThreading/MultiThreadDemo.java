package MultiThreading;

class Demo {
	public void fun1() {
		System.out.println("this is fun1");

	}

	public void fun2() {
		System.out.println("this is fun2");

	}

}

class MultiThreadDemo extends Thread {
	// ch                      parent

	Demo demo1 = new Demo();

	public void run()// overriding the thread class method
	{
		demo1.fun1();
		demo1.fun2();
		long id = Thread.currentThread().getId();
		String name = Thread.currentThread().getName();
		System.out.println("id is " + id);
		System.out.println("Thread is " + name);
	}

	public static void main(String[] args) {
		for (int i = 0; i < 7; i++) {
			MultiThreadDemo thread1 = new MultiThreadDemo ();

			thread1.start();// will call run()

			System.out.println("=============================");
		}

		/*
		 * MultiThread thread2=new MultiThread (); thread2.start();//will call run()
		 * 
		 * System.out.println("=============================");
		 * 
		 * MultiThread thread3=new MultiThread (); thread3.start();//will call run()
		 * 
		 * System.out.println("=============================");
		 */

	}

}
