package fileio;

import java.io.FileInputStream;
import java.io.IOException;

public class CheckedException1 {

	public static void main(String[] args) {
		try {
			FileInputStream fis = new FileInputStream("d:\\sagar1\\myfile123.txt");
			int k;
			// read() :read a character
			while ((k = fis.read()) != -1)// to check EOF
			{
				System.out.print((char) k);
			}
			fis.close();
		} catch (IOException e) {
			System.out.println("Error:path is wrong for the file " + e);
		}
	}
}
