package fileio;

import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {

	public static void main(String[] args)throws IOException  {
		FileReader fr=new FileReader("d:\\sagar1\\myfile.txt");
		int i;
		while ((i = fr.read()) != -1)// to check EOF
		{
			System.out.print((char) i);
		}
	}

}
