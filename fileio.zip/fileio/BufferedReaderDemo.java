package fileio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderDemo {

	public static void main(String[] args)throws IOException,FileNotFoundException {
		//File file=new File("d:\\sagar1\\myfile.txt");
		FileReader fr=new FileReader("d:\\sagar1\\myfile.txt");//(file)
		
		BufferedReader br=new BufferedReader(fr,200);
		//200: no of characters to reading at time
		//its optional so we can used or BufferedReader(fr(default));
		String str;
		while((str=br.readLine())!=null)
			// to read the line :200ch
		{
			System.out.println(str);
		}
		
	}

}
