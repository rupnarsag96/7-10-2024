package fileio;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class checkException{

	
	public static void main(String[] args) throws IOException {
		try {
			FileInputStream fis = new FileInputStream("d:\\sagar1\\myfile.txt");
			int k;
			// read() :read a character
			while ((k = fis.read()) != -1)// to check EOF
			{
				System.out.print((char) k);
			}
			fis.close();
		} catch (FileNotFoundException e) {
			System.out.println("Error:path is wrong for the file " + e);
		}

	}
}